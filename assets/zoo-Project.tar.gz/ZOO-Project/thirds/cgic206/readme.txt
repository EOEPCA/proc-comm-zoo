This is the CGIC CGI development library for C programmers.
Copyright 2009 GeoLabs SARL
Copyright 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003,
2004, Thomas Boutell and Boutell.Com, Inc.

See the file cgic.html for complete documentation in a single
HTML hypertext file to be accessed with your web browser. If you
preferer, there is a plaintext version in the file cgic.txt. 
Or see http://www.boutell.com/cgic/ for the latest copy of 
the documentation.

See the files license.txt and support.txt for terms of use and
technical support information.

