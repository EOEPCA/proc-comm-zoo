.. _client-index:

ZOO-Client 
========================

This section provides information on **ZOO-Client**, the `ZOO-Project
<http://zoo-project.org>`__ WPS JavaScript client.

.. toctree::
   :maxdepth: 2
   
   what
   howto
   example
   

