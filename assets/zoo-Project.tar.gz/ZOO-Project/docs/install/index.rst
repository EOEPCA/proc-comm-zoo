.. _install:

ZOO-Project installation
========================

The following sections will help you to install the `ZOO-Project <http://zoo-project.org>`_ Open WPS Platform on various
operating systems.

.. toctree::
   :maxdepth: 2
   
   prerequisites
   download
   installation
   debian
   opensuse
   centos
   windows



