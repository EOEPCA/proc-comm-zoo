.. _kernel_index:

ZOO-Kernel
========

This section provides information on **ZOO-Kernel** , the `ZOO-Project <http://zoo-project.org>`__ WPS server. It will help you to configure and compile ZOO-Kernel.

.. toctree::
   :maxdepth: 2
   
   what
   configuration
   mapserver
   orfeotoolbox
   sagagis
   hpc
